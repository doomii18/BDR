CREATE   PROCEDURE [int].[Get_LineageKey]
@LoadType nvarchar(1),
@TableName nvarchar(100),
@LastLoadedDate datetime
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

-- La carga para @TableName comienza ahora
DECLARE @StartLoad datetime = SYSDATETIME();

/*
Se inserta una nueva fila en la tabla Lineage, con el nombre de la tabla que ser� cargada,
la fecha de inicio de la carga, el tipo de carga y el estado de la carga.
Valores posibles para el Tipo:
- F = Carga completa
- I = Carga incremental

Valores posibles para el Estado:
- P = En progreso
- E = Error
- S = �xito
*/
INSERT INTO [int].[Lineage](
	 [TableName]
	,[StartLoad]
	,[FinishLoad]
	,[Status]
	,[Type]
	,[LastLoadedDate]
	)
VALUES (
	 @TableName
	,@StartLoad
	,NULL
	,'P'
	,@LoadType
	,@LastLoadedDate
	);

-- Si estamos haciendo una carga inicial, elimina la fecha de la carga m�s reciente para esta tabla
IF (@LoadType = 'F')
	BEGIN
		UPDATE [int].[IncrementalLoads]
		SET LoadDate = '1753-01-01'
		WHERE TableName = @TableName

		EXEC ('TRUNCATE TABLE ' + @TableName)
	END;

-- Select the key of the previously inserted row
SELECT MAX([LineageKey]) AS LineageKey
FROM [int].[Lineage]
WHERE 
	[TableName] = @TableName
	AND [StartLoad] = @StartLoad

RETURN 0;
END;

