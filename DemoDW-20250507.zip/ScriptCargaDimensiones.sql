--Script para la carga de datos a la dimension Producto.
DECLARE @LoadType nvarchar(1) = 'F';
DECLARE @TableName NVARCHAR(100)='Dim_Product';
DECLARE @Prev_LastLoaded datetime;
DECLARE @LastLoadedDate datetime;
DECLARE @LineageKey int;

DECLARE @lineage TABLE (lineage int)
DECLARE @lastload TABLE (load_date datetime)

--Establecer la fecha para la carga actual.
SELECT @LastLoadedDate = GETDATE()

--Insertamos un nuevo registro en la tabla Linaje
--Paso 3: Almacenamos la el id del nuevo registro en la variable @LineageKey para uso futuro
INSERT INTO @lineage EXEC [int].[Get_LineageKey] @LoadType, @TableName, @LastLoadedDate
SELECT TOP 1 @LineageKey = lineage from @lineage

--Paso 4
--Nos aseguramos que la tabla de staging esta vacia antes de cargar nueva informacion.
TRUNCATE TABLE Staging_Product

--PASO 5 Recuperamos la fecha de cuando la Dim_Product fue cargada por ultima vez.
--PASO 6 Almacenamos esta fecha en @Prev_LastLoadedDate variable
INSERT INTO @lastload EXEC [int].[Get_LastLoadedDate] @TableName
SELECT TOP 1 @Prev_LastLoaded = load_date FROM @lastload

--PASO 7 Cargar en la tabla de Staging los nuevos productos
--o productos que fueron modificados desde la ultima carga de Dim_Product.
INSERT INTO [dbo].[Staging_Product]
	EXEC [Demo].dbo.[Load_StagingProduct] @Prev_LastLoaded, @LastLoadedDate

--PASO 8 Transferir informacion de la tabla de staging a la dimension actual Dim_Product
EXEC [dbo].[Load_DimProduct]

SELECT * FROM Demo2025DW.dbo.Staging_Product WHERE [_Source Key]=''
SELECT * FROM Dim_Product


 