
CREATE PROCEDURE [dbo].[Load_DimProduct]
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @EndOfTime datetime =  '9999-12-31';
	DECLARE @LastDateLoaded datetime;

    BEGIN TRAN;

    -- Obtiene el linaje de la carga actual de Dim_Product
	DECLARE @LineageKey int = (SELECT TOP(1) [LineageKey]
                               FROM int.Lineage
                               WHERE [TableName] = N'Dim_Product'
                               AND [FinishLoad] IS NULL
                               ORDER BY [LineageKey] DESC);

	--Agrega un empty row al proceso de carga, necesario en toda dimension.
	IF NOT EXISTS (SELECT * FROM Dim_Product WHERE [_Source Key] = '')
	INSERT INTO [dbo].[Dim_Product]
           ([_Source Key]
           ,[Product Name]
           ,[Product Code]
           ,[Product Description]
           ,[Product Subcategory]
           ,[Product Category]
           ,[Product Department]
           ,[Unit Of Measure Code]
           ,[Unit Of Measure Name]
           ,[Unit Price]
           ,[Discontinued]
           ,[Valid From]
           ,[Valid To]
           ,[Lineage Key])
     VALUES
           ('', 'N/A', 'N/A','N/A','N/A','N/A','N/A','N/A','N/A', -1, 'N/A', '1753-01-01', '9999-12-31', -1)

	-- Actualiza la fecha de validez de los productos modificados en Dim_Product 
	-- Los registros no estaran activos, poruqe la tabla de stagin sostiene las versiones nuevas.
    UPDATE prod
    SET prod.[Valid To] = mprod.[Valid From]
    FROM 
		Dim_Product AS prod INNER JOIN 
		Staging_Product AS mprod ON prod.[_Source Key] = mprod.[_Source Key]
    WHERE prod.[Valid To] = @EndOfTime

    -- Insertar nuevos Registros desde la tabla staging de Productos hacia  Dim_Product.
	INSERT Dim_Product
		    ([_Source Key]
           ,[Product Name]
           ,[Product Code]
           ,[Product Description]
           ,[Product Subcategory]
           ,[Product Category]
           ,[Product Department]
           ,[Unit Of Measure Code]
           ,[Unit Of Measure Name]
           ,[Unit Price]
           ,[Discontinued]
           ,[Valid From]
           ,[Valid To]
           ,[Lineage Key])
    SELECT [_Source Key]
           ,[Product Name]
           ,[Product Code]
           ,[Product Description]
           ,[Product Subcategory]
           ,[Product Category]
           ,[Product Department]
           ,[Unit Of Measure Code]
           ,[Unit Of Measure Name]
           ,[Unit Price]
           ,[Discontinued]
           ,[Valid From]
           ,[Valid To]
           ,@LineageKey
    FROM Staging_Product;

    --Actualizar la tabla linaje para la carga actual, con la fecha de finalizacion y el estado de la carga
	-- en este caso 'S' para successfully
	UPDATE [int].Lineage
        SET 
			FinishLoad = SYSDATETIME(),
            Status = 'S',
			@LastDateLoaded = LastLoadedDate
    WHERE [LineageKey] = @LineageKey;
	 
	
	--Actualizar la tablas de cargas incrementales con la fecha de la carga actual para Dim_Product
	UPDATE [int].[IncrementalLoads]
        SET [LoadDate] = @LastDateLoaded
    WHERE [TableName] = N'Dim_Product';

    -- Uso de commit para finalizar la transaccion.
	COMMIT;

    RETURN 0;
END;